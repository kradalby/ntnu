package oving3;

import acm.graphics.GImage;
import acm.program.GraphicsProgram;
import java.util.ArrayList;

public class CardDeck extends GraphicsProgram{
	ArrayList<Card> cards = new ArrayList<Card>();
	
	
	public void init() {
		for (int f = 0; f < 4; f++) {
			for (int s = 1; s < 14; s++) {
				if (f==0) {
					Card meh = new Card("S",s);
					cards.add(meh);
				} else if (f == 1) {
					Card meh = new Card("H",s);
					cards.add(meh);
				} else if (f == 2) {
					Card meh = new Card("D",s);
					cards.add(meh);
				} else if (f == 3) {
					Card meh = new Card("C",s);
					cards.add(meh);
				}
			}
		}
	}
	
	public void run() {
		int count = 0;
		int y = 10;
		int x = 10;
		for (int i = 0; i < cards.size(); i++) {
			GImage meh = createGImage(cards.get(i).suit, cards.get(i).face);
			add(meh, x, y);
			x += 70;
			count++;
			if (count == 13) {
				count = 0;
				y += 215;
				x = 10;
			}
		}
	}
	
	public Card getCard(int meh) {
		return cards.get(meh);
	}
	
	GImage createGImage(String suit, int value) {
		String name="";
		switch(suit.charAt(0)){
		case 'H':
			name+="hearts";
			break;
		case 'D':
			name+="diamonds";
			break;
		case 'C':
			name+="clubs";
			break;
		case 'S':
			name+="spades";
			break;
		}
		name+="-";
		switch(value) {
		case 1:
			name+="a";
			break;
		case 11:
			name+="j";
			break;
		case 12:
			name+="q";
			break;
		case 13:
			name+="k";
			break;
		default:
			name+="" + value;
		}

		name+="-150.png";
		return new GImage("oving3/img/" + name);
	}
}