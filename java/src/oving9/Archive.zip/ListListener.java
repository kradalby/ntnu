
package oving9;

public interface ListListener {

	public void listChanged(ObservableList meh, int low, int high);
	
}
