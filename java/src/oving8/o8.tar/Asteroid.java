package oving8;

public class Asteroid extends SpaceObject {
	
	public Asteroid(double density, double radius, int corners) {
		
		this.setMass(radius*density);
		for (int i = 0; i < corners; i ++){
			this.addPolarEdge(radius*10.0, 360.0/(double)corners*i);
		}
		this.setFilled(true);
		this.recenter();
	}
	
	
	
}
